import React,{useEffect, useState} from 'react'
import {
    CButton,
    CCard,
    CCardImage,
    CContainer,
    CAlert,   
    CFooter, 
    CModal,
    CModalBody,
    CModalHeader,
    CModalTitle,
    CRow,
    CCol,
    CImage,
  } from '@coreui/react' 
import { useMoralis } from 'react-moralis'
import Web3 from 'web3'
import { nftAbi,nftAddress } from 'src/nft'
import { chainName } from 'src/global'
import { setGlobalState } from 'src/state'
import bannerImg from 'src/assets/images/1st-gen-spaceship.png'
import lootboxImg from 'src/assets/images/lootbox.png'
import {tokenAbi, tokenAddress} from "src/token"
import rewardSpaceshipImg from "src/assets/images/reward-spaceship.png"
import rewardGxgImg from "src/assets/images/reward-gxg.png"
import rewardScImg from "src/assets/images/reward-sc.png"

const SpecialOffer = () => {
    const { isAuthenticated, user, Moralis} = useMoralis();
    let ethAddress="";
    const [visible, setVisible] = useState(false);
    const [visibleModal, setVisibleModal] = useState(false);
    const [visibleModalReward, setVisibleModalReward] = useState(false);
    const [rewardImg,setRewardImg] = useState("");
    let [info,setInfo] = useState("");
    let [infoColor, setInfoColor] = useState("primary");
    let [mintPrice,setMintPrice] = useState(0);
    let [modalTitle, setModalTitle] = useState("");
    let [modalInfo, setModalInfo] = useState("");
    let [mintDisable, setMintDisable] = useState(false);
    let [lootboxDisable, setLootboxDisable] = useState(false);
    

    useEffect(async()=>{
        if(isAuthenticated){
            ethAddress = user.get('ethAddress');
            
        }
    },[])

    if(Moralis.provider){
        getMintPrice();
    }

    async function getBalance(){
        ethAddress = user.get('ethAddress');
        let web3 = new Web3(Moralis.provider);
        let contract = new web3.eth.Contract(tokenAbi, tokenAddress);
        let result = await contract.methods.balanceOf(ethAddress).call({from:ethAddress});
        setGlobalState("gxg",Math.floor(result/10**18));
    
        const params = {user_id:user.id};
        const userDetail = await Moralis.Cloud.run("syncUserDetail",params);
        setGlobalState("sc",Math.floor(userDetail.get("space_credit")));
        
    } 

    async function getMintPrice(){
        const web3 = new Web3(Moralis.provider);
        let contract = new web3.eth.Contract(nftAbi, nftAddress);
        let price = await contract.methods.minPrice().call({from:ethAddress});
        setMintPrice(price);
    }

    async function mint(){
        setMintDisable(true);
        setModalTitle("Mint new Spaceship");
        setModalInfo("Please wait...");
        setVisibleModal(true);
        ethAddress = user.get('ethAddress');
        const web3 = new Web3(Moralis.provider);
        let contract = new web3.eth.Contract(nftAbi, nftAddress);
            await setApprove(nftAddress,mintPrice);   
            await contract.methods.mintToken(ethAddress,0).send({from:ethAddress})
            .on('receipt',function(receipt){
                console.log(receipt);
                getBalance();
                setVisibleModal(false);
                setMintDisable(false);
                setInfo("Spaceship minted!");
                setInfoColor("success");
                setVisible(true);
                window.scrollTo(0, 0);
            })
            .on('error', function(error,receipt){
                console.log(error);
                setVisibleModal(false);
                setMintDisable(false);
            });            
            console.log("end");
    }

    async function mint2(){
        if(user){
            setMintDisable(true);
            setModalTitle("Mint new Spaceship");
            setModalInfo("Please wait...");
            setVisibleModal(true);
            ethAddress = user.get('ethAddress');
            await setApprove(nftAddress,mintPrice);
            const params = {ethAddress:ethAddress};   
            const result = await Moralis.Cloud.run("mintSpaceship",params);
            console.log(result);
            if(result){
                getBalance();
                setVisibleModal(false);
                setMintDisable(false);
                setInfo("Spaceship minted!");
                setInfoColor("success");
                setVisible(true);
                window.scrollTo(0, 0);
            }
        }else{
            setInfo("Connect your wallet!");
            setInfoColor("danger");
            setVisible(true);
            window.scrollTo(0, 0);
        }
    }

    async function setApprove(contractAddress,price){   
        ethAddress = user.get('ethAddress');
        const web3 = new Web3(Moralis.provider);
        let contract = new web3.eth.Contract(tokenAbi, tokenAddress);
        const BN = web3.utils.BN;        
        console.log("approve");
        const allowanceValue = new BN(price.toString);
        let transaction = await contract.methods.approve(contractAddress,allowanceValue.toString()).send({from:ethAddress});
        console.log(transaction);  
      }


    async function lootbox(){
        if(user){
            setLootboxDisable(true);
            setInfo("Buying treasure...");
            setInfoColor("warning");
            setVisible(true);
            window.scrollTo(0, 0);
            ethAddress = user.get('ethAddress');
            const params = {user_id:user.id,ethAddress:ethAddress};
            const result = await Moralis.Cloud.run("normalLootbox",params);  
            await getBalance();
            if(result[0]=="spaceship"){
                setRewardImg(rewardSpaceshipImg);
            }else if(result[0]=="gxg"){
                setRewardImg(rewardGxgImg);
            }else if(result[0]=="sc"){
                setRewardImg(rewardScImg);
            } 
            setLootboxDisable(false);
            setInfo(result[1]);
            setVisible(false);
            setVisibleModalReward(true);
        }else{
            setInfo("Connect your wallet!");
            setInfoColor("danger");
            setVisible(true);
            window.scrollTo(0, 0);
        }
    }

    return ( 
        <CContainer>
            <CAlert color={infoColor} dismissible visible={visible} onClose={() => setVisible(false)}>{info}</CAlert>
            <CRow className='mb-4'>
                <CCol>
                    <CCard>
                        <CCardImage src={bannerImg}/>
                        <CFooter>
                            <CButton onClick={()=>mint2()} disabled={mintDisable}>Mint {mintPrice/10**18} GXG</CButton>
                        </CFooter>
                    </CCard>
                </CCol>
                <CCol>
                    <CCard >
                            <CCardImage src={lootboxImg}/>
                            <CFooter>
                                <CButton onClick={()=>lootbox()} disabled={lootboxDisable}>Buy 1000 SC</CButton>
                            </CFooter>
                    </CCard>
                </CCol>
            </CRow>            
            <CModal visible={visibleModal} onClose={() => setVisibleModal(false)}>
                <CModalHeader onClose={() => setVisibleModal(false)}>        
                    <CModalTitle>{modalTitle}</CModalTitle>        
                </CModalHeader>        
                <CModalBody>
                    {modalInfo}
                </CModalBody>         
            </CModal>
            <CModal visible={visibleModalReward} onClose={() => setVisibleModalReward(false)}>
                <CModalHeader onClose={() => setVisibleModalReward(false)}>        
                    <CModalTitle>{info}</CModalTitle>        
                </CModalHeader>        
                <CModalBody>
                    <CCard>
                        <CImage src={rewardImg} />
                    </CCard>
                </CModalBody>         
            </CModal>
        </CContainer>
       )
}

export default SpecialOffer