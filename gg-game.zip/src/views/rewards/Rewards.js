import { CRow,
CContainer,
CCardBody,
CCardText,
CAlert,
CCard,
CTable,
CTableBody,
CTableHeaderCell,
CTableRow,
CTableHead,
CTableDataCell,
CPagination,
CPaginationItem} from '@coreui/react'
import React,{useEffect, useState} from 'react'
import { useMoralis } from 'react-moralis'

const Rewards = () => {
    const { isAuthenticated, user, Moralis } = useMoralis();
    let ethAddress="";
    let [rewards,setRewards] = useState([]);
    const [visible, setVisible] = useState(false);
    let [info,setInfo] = useState("");
    let [infoColor, setInfoColor] = useState("primary");
    let [page, setPage] = useState(1);

    useEffect(async()=>{
        if(isAuthenticated){
            ethAddress = user.get('ethAddress');
            await getRewards(page);
        }
    },[])


    async function getRewards(p){  
        if(user){
            console.log('page ',p)      
            const params = {user_id:user.id,page:p};        
            const resultRewards = await Moralis.Cloud.run("rewards",params);        
            setRewards(resultRewards);
        }else{
            setInfo("Connect your wallet!");
            setInfoColor("danger");
            setVisible(true);
            window.scrollTo(0, 0);
        }
    }

    function previousPage(){
        let p=1;
        if(page>3){
            p = page-3;
        }else if(page>1 && page<=3){
            p = page-1;
        }
        setPage(p);
        getRewards(p);
    }

    function nextPage(){
        const p = page+3;
        setPage(p);
        getRewards(p);
    }

    function gotoPage(p){
        console.log('p ',p)
        setPage(p);
        getRewards(p);
    }

    return ( 
        <CContainer>
            <CAlert color={infoColor} dismissible visible={visible} onClose={() => setVisible(false)}>{info}</CAlert>
            <CCard className='p-4'>                 
                <CCardBody>
                <CTable>
                    <CTableHead>
                        <CTableRow>
                        <CTableHeaderCell scope="col">#</CTableHeaderCell>
                        <CTableHeaderCell scope="col">Reward</CTableHeaderCell>
                        <CTableHeaderCell scope="col">Date</CTableHeaderCell>
                        <CTableHeaderCell scope="col">Amount</CTableHeaderCell>
                        <CTableHeaderCell scope="col">Status</CTableHeaderCell>
                        <CTableHeaderCell scope="col">Trx Hash</CTableHeaderCell>
                        <CTableHeaderCell scope="col">Info</CTableHeaderCell>
                        </CTableRow>
                    </CTableHead>
                    <CTableBody>
                    {
                        rewards.map((reward,i) => 
                        <CTableRow key={i}>
                            <CTableHeaderCell scope="row">{i+1}</CTableHeaderCell>
                            <CTableDataCell>{reward.lootbox.reward}</CTableDataCell>
                            <CTableDataCell>{new Date(reward.lootbox.createdAt).getMonth()}/{new Date(reward.lootbox.createdAt).getDate()}/{new Date(reward.lootbox.createdAt).getFullYear()} {new Date(reward.lootbox.createdAt).getHours()}:{new Date(reward.lootbox.createdAt).getMinutes()}</CTableDataCell>
                            <CTableDataCell>{reward.lootbox.amount}</CTableDataCell>
                            <CTableDataCell>{reward.reward!= null?reward.reward.get('status'):'Claimed'}</CTableDataCell>
                            <CTableDataCell>{reward.reward!= null?reward.reward.get('trx_hash'):''}</CTableDataCell>
                            <CTableDataCell>{reward.reward!= null?reward.reward.get('info'):''}</CTableDataCell>
                        </CTableRow>
                        )
                    }   
                    
                    </CTableBody>
                </CTable>
                </CCardBody>
                <CPagination >
                    <CPaginationItem onClick={()=>previousPage()}>Previous</CPaginationItem>
                    <CPaginationItem onClick={()=>gotoPage(page)}>{page}</CPaginationItem>
                    <CPaginationItem onClick={()=>gotoPage(page+1)}>{page+1}</CPaginationItem>
                    <CPaginationItem onClick={()=>gotoPage(page+2)}>{page+2}</CPaginationItem>
                    <CPaginationItem onClick={()=>nextPage()}>Next</CPaginationItem>
                </CPagination>
            </CCard>
        </CContainer>
       )
}

export default Rewards