import React from 'react'
import {
    CButton,
    CCard,
    CCardImage,
    CContainer,
    CAlert,   
    CFooter, 
    CRow,
    CCol,
  } from '@coreui/react' 
import imgHowToPlay from 'src/assets/images/howtoplay.png'
import imgPlay from 'src/assets/images/download.png'

const PlayGame = () => {

    return ( 
        <CContainer>
            <CRow className='mb-4'>
                <CCol></CCol>
                <CCol>
                    <a href='https://satrio-galih.gitbook.io/galaxy-gang/' target='_blank'><img src={imgHowToPlay} /></a>
                </CCol>
                <CCol></CCol>
            </CRow>
            <CRow className='mb-4'>
                <CCol></CCol>
                <CCol>
                <a href='https://galaxygang-game.netlify.app/' target='_blank'><img src={imgPlay}/></a>
                </CCol>
                <CCol></CCol>
            </CRow>
        </CContainer>
       )
}

export default PlayGame