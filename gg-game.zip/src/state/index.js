import { createGlobalState } from "react-hooks-global-state";

const {setGlobalState, useGlobalState} = createGlobalState ({
    gxg: 0,
    sc: 0,
    firstAccess: 1
})

export{setGlobalState, useGlobalState};