import React, {useState, useEffect} from 'react'
import { useSelector, useDispatch } from 'react-redux'
import {
  CContainer,
  CHeader,
  CHeaderBrand,
  CHeaderDivider,
  CHeaderNav,
  CHeaderToggler,
  CNavLink,
  CNavItem,
  CButton
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilMenu } from '@coreui/icons'
import { useNavigate } from 'react-router-dom'
import { AppBreadcrumb } from './index'
import { useMoralis, Moralis } from 'react-moralis'
import Web3 from 'web3'
import {tokenAbi, tokenAddress} from "../token"
import { setGlobalState, useGlobalState } from 'src/state'
import logoImg from 'src/assets/images/logo-small.png'
import { chainName, chainId } from 'src/global'

const AppHeader = () => {  
  const dispatch = useDispatch()
  const sidebarShow = useSelector((state) => state.sidebarShow);
  const [myGxg] = useGlobalState("gxg");
  const [mySc] = useGlobalState("sc");
  const [ethAddressShort,setEthAddressShort] = useState("");
  const { authenticate, isAuthenticated, user, logout, Moralis } = useMoralis(); 
  let navigate = useNavigate();
  let ethAddress = "";
  //let ethAddressShort = "";

  const login = async () => {
    if (!isAuthenticated) {

      await authenticate({signingMessage: "Log in using Moralis" })
        .then(function (user) {
          console.log("logged in user:", user);
          console.log("ethAddress "+!user.get('ethAddress'));
          ethAddress = user.get('ethAddress');
          location.reload();
        })
        .catch(function (error) {
          console.log(error);
        });
    }
  }  

  const logOut = async () => {
    await logout();
    console.log("logged out");
  }

  useEffect(async () => {
    if(isAuthenticated){
      console.log("authed");
      ethAddress = user.get('ethAddress');
      setEthAddressShort(ethAddress.substring(0,5)+"..."+ethAddress.substring(ethAddress.length-4,ethAddress.length));
      
      getBalance();
      
    }

    

    Moralis.onAccountChanged( async (account) => {
      await logout();
      //location.reload();
      navigate("/", { replace: true });
    });
  },[])  

  async function getBalance(){
    if(!Moralis.isWeb3Enabled()){
      await Moralis.enableWeb3();
      const chainid = await Moralis.chainId;
      console.log("chain id ",chainId);
      if(chainid!=chainId){
        await Moralis.switchNetwork(chainId);
      }
    }
    let web3 = new Web3(Moralis.provider);
    let contract = new web3.eth.Contract(tokenAbi, tokenAddress);
    let result = await contract.methods.balanceOf(ethAddress).call({from:ethAddress});
    setGlobalState("gxg",Math.floor(result/10**18));

    const params = {user_id:user.id};
    const userDetail = await Moralis.Cloud.run("syncUserDetail",params);
    setGlobalState("sc",Math.floor(userDetail.get("space_credit")));
    
  } 
  
  const renderLoginButton = () => {
    if(!isAuthenticated){
      return <CButton color="primary" onClick={login}>Connect Wallet</CButton>
    }else{
      return <CButton color="primary" disabled>{ethAddressShort}</CButton>
    }
  }

  const toHome = () =>{
      let path = "start"; 
      navigate(path);
  }

  return (
    <CHeader position="sticky" className="mb-4">
      <CContainer fluid>
        <CHeaderToggler
          className="ps-1"
          onClick={() => dispatch({ type: 'set', sidebarShow: !sidebarShow })}
        >
          <CIcon icon={cilMenu} size="lg" />
        </CHeaderToggler>
        <CHeaderBrand className="mx-auto d-md-none" to="/">
          <img src={logoImg} height={48} alt="Logo" onClick={toHome}/>
        </CHeaderBrand>
        <CHeaderNav className="d-none d-md-flex me-auto">
          <CNavItem>
            <CNavLink href="https://satrio-galih.gitbook.io/galaxy-gang/" target='_blank'>How To Play</CNavLink>
          </CNavItem>
        </CHeaderNav>
        <CHeaderNav>
          <CNavItem>
          <div className="p-2">GXG : {myGxg}</div>
          </CNavItem> 
          <CNavItem>
            <div className="p-2">SC : {mySc}</div>
          </CNavItem>          
        </CHeaderNav>
        <CHeaderNav >
          {renderLoginButton()}          
        </CHeaderNav>
      </CContainer>
      <CHeaderDivider />
      <CContainer fluid>
        <AppBreadcrumb />
      </CContainer>
    </CHeader>
  )
}

export default AppHeader
