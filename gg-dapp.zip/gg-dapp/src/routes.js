import React from 'react'

const Spaceships = React.lazy(() => import('./views/spaceships/Spaceships'))
const Spaceship = React.lazy(() => import('./views/marketplace/spaceship/Spaceship'))
const SpaceCredit = React.lazy(() => import('./views/marketplace/sc/SpaceCredit'))
const SpecialOffer = React.lazy(() => import('./views/special_offer/SpecialOffer'))
const Fusion = React.lazy(() => import('./views/fusion/Fusion'))
const Rewards = React.lazy(() => import('./views/rewards/Rewards'))
const Profile = React.lazy(() => import('./views/profile/Profile'))
const PlayGame = React.lazy(() => import('./views/play_game/PlayGame'))
const Home = React.lazy(() => import('./views/home/Home'))



const routes = [
  { path: '/', exact: true, name: 'Home' },
  { path: '/home', name: 'Start', element: Home },
  { path: '/spaceships', name: 'Spaceships', element: Spaceships },
  { path: '/marketplace', name: 'Marketplace', element: Spaceship, exact: true },
  { path: '/marketplace/spaceship', name: 'Spaceship', element: Spaceship },
  { path: '/marketplace/sc', name: 'Space Credit', element: SpaceCredit },
  { path: '/special_offer', name: 'SpecialOffer', element: SpecialOffer },
  { path: '/fusion', name: 'Fusion', element: Fusion },
  { path: '/rewards', name: 'Rewards', element: Rewards },
  { path: '/profile', name: 'Profile', element: Profile },
  { path: '/play_game', name: 'PlayGame', element: PlayGame },
]

export default routes
