import React,{useEffect, useState} from 'react'
import {
    CButton,
    CCard,
    CCardBody,
    CCardHeader,
    CCardImage,
    CCol,
    CContainer,
    CProgress,
    CProgressBar,
    CRow, 
    CAlert,       
    CPagination,
    CPaginationItem 
  } from '@coreui/react'  
import { useMoralis } from 'react-moralis'
import Web3 from 'web3'
import { nftAbi,nftAddress } from 'src/nft'
import { setGlobalState } from 'src/state'
import { tokenAbi,tokenAddress } from 'src/token'

const Fusion = () => {

    const { isAuthenticated, user, Moralis } = useMoralis();
    let ethAddress="";
    let [spaceships, setSpaceships] = useState([]);
    const [visible, setVisible] = useState(false);
    let [info,setInfo] = useState("");
    let [infoColor, setInfoColor] = useState("primary");
    let [disabled,setDisabled] = useState(false);
    let [parent1, setParent1] = useState("");
    let [parent2, setParent2] = useState("");
    let [fusePrice, setFusePrice] = useState(0);
    let [page, setPage] = useState(1);
    

    useEffect(async()=>{
        if(isAuthenticated){
            ethAddress = user.get('ethAddress');
            await getSpaceships();
        }
    },[])

    async function getBalance(){
        ethAddress = user.get('ethAddress');
        let web3 = new Web3(Moralis.provider);
        let contract = new web3.eth.Contract(tokenAbi, tokenAddress);
        let result = await contract.methods.balanceOf(ethAddress).call({from:ethAddress});
        setGlobalState("gxg",Math.floor(result/10**18));
    
        const params = {user_id:user.id};
        const userDetail = await Moralis.Cloud.run("syncUserDetail",params);
        setGlobalState("sc",Math.floor(userDetail.get("space_credit")));
        
      }  

    async function getSpaceships(p) {//get list of all owned NFTs and sync to the database  
        if(user){
            const params = {user_id:user.id,page:p};      

            const ships= await Moralis.Cloud.run("spaceships",params);
            console.log('spaceships ',spaceships)
            
            setSpaceships(ships);  
        }else{
            setInfo("Connect your wallet!");
            setInfoColor("danger");
            setVisible(true);
            window.scrollTo(0, 0);
        }
    }    

    function fuseSelect(spaceship){
        if(parent1==""){
            setParent1(spaceship);
            setInfo("1st Spaceship Selected!");
            setInfoColor("success");
        }else{
            if(spaceship.objectId!=parent1.objectId){
                if(spaceship.rarity==parent1.rarity){
                    setParent2(spaceship);
                    setInfo("2nd Spaceship Selected!");
                    setInfoColor("success");
                    getFusePrice();
                }else{
                    setInfo("Spaceship must be in same rarity!");
                    setInfoColor("warning");
                }
            }else{
                setInfo("Spaceship already selected!");
                setInfoColor("warning");
            }
        }

        
        
        setVisible(true);
        window.scrollTo(0, 0);
    }

    function fuseReset(){
        setParent1('');
        setParent2('');
        setInfo("Fuse Reset!");
        setInfoColor("warning");
        setVisible(true);
        window.scrollTo(0, 0);
    }

    async function getFusePrice(){
        ethAddress = user.get('ethAddress');
        const web3 = new Web3(Moralis.provider);
        let contract = new web3.eth.Contract(nftAbi, nftAddress);
        let breedPrice = await contract.methods.breedPrice().call({from:ethAddress});
        console.log("price"+breedPrice);   
        if(parent1.rarity="1"){
            breedPrice = breedPrice*2;
        }else if(parent1.rarity="2"){
            breedPrice = breedPrice*3;
        }else if(parent1.rarity="3"){
            breedPrice = breedPrice*4;
        }else if(parent1.rarity="4"){
            breedPrice = breedPrice*4;
        }else
        
        setFusePrice(breedPrice/10**18);
    }

    async function checkAllowance(){
        ethAddress = user.get('ethAddress');
        const web3 = new Web3(Moralis.provider);
        let contract = new web3.eth.Contract(tokenAbi, tokenAddress);
        let allowance = await contract.methods.allowance(ethAddress,nftAddress).call({from:ethAddress});
        console.log("allowance "+allowance);
        return allowance;
      }

    async function fusion(){
        if(user){
            ethAddress = user.get('ethAddress');
            const web3 = new Web3(Moralis.provider);
            let contract = new web3.eth.Contract(nftAbi, nftAddress);
            let breedPrice = await contract.methods.breedPrice().call({from:ethAddress});
            console.log("price"+breedPrice);   
            breedPrice = breedPrice*parseInt(parent1.rarity);
            console.log("price rarity "+breedPrice);
            let allowance = await checkAllowance();
            if(allowance<breedPrice){
                await setApprove(nftAddress,breedPrice);
                fusion();
            }else{    
                const params = {ethAddress:ethAddress,parent1id:parent1.token_id,parent2id:parent2.token_id};
                const result = await Moralis.Cloud.run("fusion",params);
                if(result){
                    setInfo("Fusion success!");
                    setInfoColor("success");
                    setVisible(true);
                    window.scrollTo(0, 0);
                    await getBalance();
                    await getSpaceships(page);
                }
                //let parent1id = parent1.token_id-1;
                //let parent2id = parent2.token_id-1;
                //console.log('fuse '+parent1id+" "+parent2id)
            /*await contract.methods.breeding(parent1id,parent2id).send({from:ethAddress})
            .on('receipt',async function(receipt){
                console.log(receipt);
                setInfo("Fusion success!");
                setInfoColor("success");
                setVisible(true);
                window.scrollTo(0, 0);
                await getBalance();
                await getSpaceships(page);
            })
            .on('error', function(error,receipt){
                console.log(error);
            });*/      
            console.log("end");
            }
        }else{
            setInfo("Connect your wallet!");
            setInfoColor("danger");
            setVisible(true);
            window.scrollTo(0, 0);
        }
    }

    async function setApprove(contractAddress,price){   
        ethAddress = user.get('ethAddress');
        const web3 = new Web3(Moralis.provider);
        let contract = new web3.eth.Contract(tokenAbi, tokenAddress);
        const BN = web3.utils.BN;
        const priceBig = price*10**18;
        console.log("approve");
        const allowanceValue = new BN(priceBig.toString);
        let transaction = await contract.methods.approve(contractAddress,allowanceValue.toString()).send({from:ethAddress});
        console.log(transaction);  
      }

      function previousPage(){
        let p=1;
        if(page>3){
            p = page-3;
        }else if(page>1 && page<=3){
            p = page-1;
        }
        setPage(p);
        getSpaceships(p);
    }

    function nextPage(){
        const p = page+3;
        setPage(p);
        getSpaceships(p);
    }

    function gotoPage(p){
        console.log('p ',p)
        setPage(p);
        getSpaceships(p);
    }

    return ( 
        <CContainer>
            <CAlert color={infoColor} dismissible visible={visible} onClose={() => setVisible(false)}>{info}</CAlert>
            <CCard className='mb-4'>
                <CCardBody>  
                   <CRow className='mb-2'>
                        <CCol>
                            1st Spaceship Selected: {parent1!=''?parent1.name+' '+parent1.token_id:''}
                        </CCol>   
                    </CRow>
                    <CRow className='mb-2'>
                        <CCol>
                            2nd Spaceship Selected: {parent2!=''?parent2.name+' '+parent2.token_id:''}
                        </CCol>   
                    </CRow>   
                    <CRow>
                        <CCol >
                            <CButton className='m-2' color="primary" onClick={()=>fusion()}>Fuse {fusePrice} GXG</CButton><CButton color="secondary" onClick={()=>fuseReset()}>Reset</CButton>
                        </CCol>
                    </CRow>                              
                </CCardBody>
            </CCard>
            <CRow>
                {
                    spaceships.map((spaceship,i) => 
                        <CCol sm='auto' key={spaceship.token_id}>
                            <CCard className='mb-4' style={{width: '18rem'}}>
                                <CCardHeader><b>{spaceship.name} {spaceship.token_id}</b></CCardHeader>
                                <CCardImage orientation='top' src={spaceship.image}/>                                
                                <CCardBody>                                  
                                    <CRow >
                                        <CCol>
                                            Life :
                                        </CCol>
                                        <CCol>
                                            <CProgress >
                                                <CProgressBar value={spaceship.health/5*100} >{spaceship.health}</CProgressBar>
                                            </CProgress>                                            
                                        </CCol>                                        
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Level :
                                        </CCol>
                                        <CCol>
                                        <CProgress >
                                                <CProgressBar value={spaceship.level/20*100} >{spaceship.level}</CProgressBar>
                                            </CProgress>
                                        </CCol>
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Durability :
                                        </CCol>
                                        <CCol>
                                        <CProgress >
                                                <CProgressBar value={spaceship.durability/spaceship.durability_max*100} >{spaceship.durability}</CProgressBar>
                                            </CProgress>
                                        </CCol>
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Power :
                                        </CCol>
                                        <CCol>
                                        <CProgress >
                                                <CProgressBar value={spaceship.power/5*100} >{spaceship.power}</CProgressBar>
                                            </CProgress>
                                        </CCol>
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Weapon 1 :
                                        </CCol>
                                        <CCol>
                                        {spaceship.weapon1}
                                        </CCol>
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Weapon 2 :
                                        </CCol>
                                        <CCol>
                                        {spaceship.weapon2}
                                        </CCol>
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Weapon 3 :
                                        </CCol>
                                        <CCol>
                                        {spaceship.weapon3}
                                        </CCol>
                                    </CRow>
                                    <CRow className='mb-2'>
                                        <CCol>
                                            Special :
                                        </CCol>
                                        <CCol>
                                        {spaceship.special}
                                        </CCol>
                                    </CRow>                                    
                                    <CRow className='mb-2'>
                                        <CCol>
                                            <CButton onClick={()=>fuseSelect(spaceship)}>Select</CButton>
                                        </CCol>
                                    </CRow>  
                                </CCardBody>
                            </CCard>
                        </CCol>  
                    )
                }           
            </CRow>
            <CPagination >
                <CPaginationItem onClick={()=>previousPage()}>Previous</CPaginationItem>
                <CPaginationItem onClick={()=>gotoPage(page)}>{page}</CPaginationItem>
                <CPaginationItem onClick={()=>gotoPage(page+1)}>{page+1}</CPaginationItem>
                <CPaginationItem onClick={()=>gotoPage(page+2)}>{page+2}</CPaginationItem>
                <CPaginationItem onClick={()=>nextPage()}>Next</CPaginationItem>
            </CPagination>
        </CContainer>
       )
}

export default Fusion