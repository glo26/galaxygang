import React,{useEffect, useState}  from 'react'
import {
    CButton,
    CCard,
    CCardBody,
    CCardHeader,
    CCardImage,
    CCol,
    CContainer,
    CRow, 
    CAlert,   
    CFormInput,
    CForm,
    CPagination,
    CPaginationItem  
  } from '@coreui/react' 
import { useMoralis } from 'react-moralis'
import Web3 from 'web3'
import { mpAbi, mpAddress } from 'src/marketplace'
import { tokenAbi, tokenAddress } from 'src/token'
import coinsImg from 'src/assets/images/coins.png'
import { setGlobalState, useGlobalState } from 'src/state'

const SpaceCredit = () => {
    const { isAuthenticated, user, Moralis } = useMoralis();
    let ethAddress="";
    let [marketplace, setMarketplace] = useState([]);
    const [visible, setVisible] = useState(false);
    let [info,setInfo] = useState("");
    let [infoColor, setInfoColor] = useState("primary");
    let [priceInput,setPriceInput] = useState("");
    let [page, setPage] = useState(1);
    const [myGxg] = useGlobalState("gxg");
    const [mySc] = useGlobalState("sc");

    useEffect(async()=>{
        if(isAuthenticated){
            ethAddress = user.get('ethAddress');
            getMarketplace("space_credit",page);
        }
    },[])

    async function getBalance(){
        ethAddress = user.get('ethAddress');
        let web3 = new Web3(Moralis.provider);
        let contract = new web3.eth.Contract(tokenAbi, tokenAddress);
        let result = await contract.methods.balanceOf(ethAddress).call({from:ethAddress});
        setGlobalState("gxg",Math.floor(result/10**18));
    
        const params = {user_id:user.id};
        const userDetail = await Moralis.Cloud.run("syncUserDetail",params);
        setGlobalState("sc",Math.floor(userDetail.get("space_credit")));
        
      } 

    async function getMarketplace(type,p){
        if(user){
            const params = {type:type,page:p};
            const onSale = await Moralis.Cloud.run("getMarketplace",params);
            setMarketplace(onSale);
            console.log('market ',onSale);
        }else{
            setInfo("Connect your wallet!");
            setInfoColor("danger");
            setVisible(true);
            window.scrollTo(0, 0);        
        }
    }

    async function buying(mp_id){
        ethAddress = user.get('ethAddress');
        const web3 = new Web3(Moralis.provider);
        let mpContract = new web3.eth.Contract(mpAbi, mpAddress);
        const price = await mpContract.methods.viewPriceSc(mp_id).call({from:ethAddress});
        await setApprove(mpAddress,price);
        await mpContract.methods.buyingSc(mp_id).send({from:ethAddress})
        .on('receipt',async function(receipt){
            console.log(receipt);
            //console.log(receipt.transactionHash);
            const params = {mp_id:mp_id,user_id:user.id,ethAddress:ethAddress};
            await Moralis.Cloud.run("buyingSc",params);
            setInfo("Space Credit Bought!");
            setInfoColor("success");
            setVisible(true);
            window.scrollTo(0, 0);
            await getMarketplace("space_credit",page);
            await getBalance();
        })
        .on('error', function(error,receipt){
          console.log(error);
        });
      }

    async function sellSc(){
        if(user){
            setInfo("Please wait...");
            setInfoColor("warning");
            setVisible(true);
            const user = Moralis.User.current();
            const ethAddress = user.get('ethAddress');
            const web3 = new Web3(Moralis.provider);
            const BN = web3.utils.BN;
            const price = priceInput;

            const params = {user_id:user.id, ethAddress:ethAddress, price:price};
            const marketId = await Moralis.Cloud.run("sellSC",params); 

            if(marketId){
                let priceBN = new BN((price*10**18).toString());
                let mpContract = new web3.eth.Contract(mpAbi, mpAddress);
                await mpContract.methods.sellingSc(marketId,priceBN.toString()).send({from:ethAddress})
                .on('receipt',async function(receipt){
                    console.log(receipt);
                    //console.log(receipt.transactionHash);
                    setInfo("Space Credit on Sale!");
                    setInfoColor("success");
                    setVisible(true);
                    window.scrollTo(0, 0);
                    await getMarketplace("space_credit",page);
                    await getBalance();
                })
                .on('error', function(error,receipt){
                console.log(error);
                });
            }else{
                setInfo("Space Credit not enough!");
                setInfoColor("danger");
                setVisible(true);
                window.scrollTo(0, 0);
            }
        }   else{
            setInfo("Connect your wallet!");
            setInfoColor("danger");
            setVisible(true);
            window.scrollTo(0, 0);
        }
    }

    async function setApprove(contractAddress, price){   
        ethAddress = user.get('ethAddress');
        const web3 = new Web3(Moralis.provider);
        let contract = new web3.eth.Contract(tokenAbi, tokenAddress);
        const BN = web3.utils.BN;
        console.log("approve");
        const allowanceValue = new BN(price.toString());
        let transaction = await contract.methods.approve(contractAddress,allowanceValue.toString()).send({from:ethAddress});
        console.log(transaction);  
    }

    function previousPage(){
        let p=1;
        if(page>3){
            p = page-3;
        }else if(page>1 && page<=3){
            p = page-1;
        }
        setPage(p);
        getMarketplace('spaceship',p);
    }

    function nextPage(){
        const p = page+3;
        setPage(p);
        getMarketplace('spaceship',p);
    }

    function gotoPage(p){
        console.log('p ',p)
        setPage(p);
        getMarketplace('spaceship',p);
    }

    const RenderBuyBtn = (props) => {
        if(user){
            ethAddress = user.get('ethAddress');        
            if(props.seller!=ethAddress){
                return <CRow className='mb-2'>
                    <CCol>
                        <CButton onClick={()=>buying(props.object_id)}>Buy {props.price/10**18} GXG</CButton>
                    </CCol>
                </CRow>    
            }else{
                return <></>
            }
        }else{
            return <></>
        }
    }

    return ( 
        <CContainer>
            <CAlert color={infoColor} dismissible visible={visible} onClose={() => setVisible(false)}>{info}</CAlert>
            <CCard className='mb-4'>
                <CCardBody>  
                    <CForm>
                        <CRow>
                            <CCol sm={4}>
                                <CFormInput type='number' id='inputScPrice' placeholder='Input GXG Price' onInput={(e) => setPriceInput(e.target.value)} onKeyPress={(event) => {
        if (!/[0-9]/.test(event.key)) {
          event.preventDefault();
        }
      }}/>
                            </CCol>
                            <CCol>
                                <CButton onClick={()=>sellSc()}>Sell 500 SC</CButton>
                            </CCol>
                        </CRow>      
                    </CForm>                                
                </CCardBody>
            </CCard>
            <CRow>
                {
                    marketplace.map((market,i) => 
                        <CCol sm='auto' key={market.objectId}>
                            <CCard className='mb-4' style={{width: '18rem'}}>
                                <CCardHeader><b>{market.sc_amount} SC</b></CCardHeader>
                                <CCardImage orientation='top' src={coinsImg}/>                                
                                <CCardBody> 
                                    <CRow className='mb-2'>
                                        <CCol>
                                            Seller
                                        </CCol>
                                        <CCol>
                                            {market.ethAddress.substring(0,5)+'...'+market.ethAddress.substring(market.ethAddress.length-4,market.ethAddress.length)}
                                        </CCol>
                                    </CRow>   
                                    <RenderBuyBtn object_id={market.objectId} seller={market.ethAddress} price={market.price}></RenderBuyBtn>                              
                                </CCardBody>
                            </CCard>
                        </CCol>  
                    )
                }           
            </CRow>
            <CPagination >
                <CPaginationItem onClick={()=>previousPage()}>Previous</CPaginationItem>
                <CPaginationItem onClick={()=>gotoPage(page)}>{page}</CPaginationItem>
                <CPaginationItem onClick={()=>gotoPage(page+1)}>{page+1}</CPaginationItem>
                <CPaginationItem onClick={()=>gotoPage(page+2)}>{page+2}</CPaginationItem>
                <CPaginationItem onClick={()=>nextPage()}>Next</CPaginationItem>
            </CPagination>
        </CContainer>
       )
}

export default SpaceCredit