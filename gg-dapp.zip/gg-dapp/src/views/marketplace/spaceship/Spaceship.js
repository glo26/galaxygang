import React,{useEffect, useState}  from 'react'
import {
    CButton,
    CCard,
    CCardBody,
    CCardHeader,
    CCardImage,
    CCol,
    CContainer,
    CProgress,
    CProgressBar,
    CRow, 
    CAlert,
    CPagination,
    CPaginationItem   
  } from '@coreui/react' 
import { useMoralis } from 'react-moralis'
import Web3 from 'web3'
import { mpAbi, mpAddress } from 'src/marketplace'
import { tokenAbi, tokenAddress } from 'src/token'
import { setGlobalState, useGlobalState } from 'src/state'

const Spaceship = () => {
    const { isAuthenticated, user, Moralis } = useMoralis();
    let ethAddress="";
    let [marketplace, setMarketplace] = useState([]);
    const [visible, setVisible] = useState(false);
    let [info,setInfo] = useState("");
    let [infoColor, setInfoColor] = useState("primary");
    let [page, setPage] = useState(1);
    const [myGxg] = useGlobalState("gxg");
    const [mySc] = useGlobalState("sc");

    useEffect(async()=>{
        if(isAuthenticated){
            ethAddress = user.get('ethAddress');
            getMarketplace("spaceship",page);
        }
    },[])

    async function getBalance(){
        ethAddress = user.get('ethAddress');
        let web3 = new Web3(Moralis.provider);
        let contract = new web3.eth.Contract(tokenAbi, tokenAddress);
        let result = await contract.methods.balanceOf(ethAddress).call({from:ethAddress});
        setGlobalState("gxg",Math.floor(result/10**18));
    
        const params = {user_id:user.id};
        const userDetail = await Moralis.Cloud.run("syncUserDetail",params);
        setGlobalState("sc",Math.floor(userDetail.get("space_credit")));
        
    } 

    async function getMarketplace(type,p){
        if(user){
            const params = {type:type, page:p};
            const onSale = await Moralis.Cloud.run("getMarketplace",params);
            let listing = [];

            for(let i=0;i<onSale.length;i++){
                const shipQuery = new Moralis.Query("Spaceships");
                shipQuery.equalTo("token_id",onSale[i].spaceship_id);
                let spaceship = await shipQuery.first();
                listing.push(
                    {spaceship:spaceship,onSale:onSale[i]}
                );
            }
            setMarketplace(listing);
        }else{
            setInfo("Connect your wallet!");
                setInfoColor("danger");
                setVisible(true);
                window.scrollTo(0, 0);
        }
    }

    async function buying(spaceship_id){
        ethAddress = user.get('ethAddress');
        const web3 = new Web3(Moralis.provider);
        let mpContract = new web3.eth.Contract(mpAbi, mpAddress);
        const price = await mpContract.methods.viewPrice(spaceship_id).call({from:ethAddress});
        console.log('spaceship id ',spaceship_id)
        await setApprove(mpAddress,price);
        await mpContract.methods.buying(spaceship_id).send({from:ethAddress})
        .on('receipt',async function(receipt){
            console.log(receipt);
            //console.log(receipt.transactionHash);
            const params = {ship_id:spaceship_id,user_id:user.id,ethAddress:ethAddress};
            await Moralis.Cloud.run("buying",params);
            setInfo("Spaceship Bought!");
            setInfoColor("success");
            setVisible(true);
            window.scrollTo(0, 0);
            await getMarketplace("spaceship",page);
            await getBalance();
        })
        .on('error', function(error,receipt){
          console.log(error);
        });
    }

    async function setApprove(contractAddress,price){   
        ethAddress = user.get('ethAddress');
        const web3 = new Web3(Moralis.provider);
        let contract = new web3.eth.Contract(tokenAbi, tokenAddress);
        const BN = web3.utils.BN;
        console.log("approve");
        const allowanceValue = new BN(price.toString());
        let transaction = await contract.methods.approve(contractAddress,allowanceValue.toString()).send({from:ethAddress});
        console.log(transaction);  
    }

    const RenderBuyBtn = (props) => {
        if(user){
            ethAddress = user.get('ethAddress');        
            if(props.seller!=ethAddress){
                return <CRow className='mb-2'>
                    <CCol>
                        <CButton onClick={()=>buying(props.spaceship_id)}>Buy {props.price} GXG</CButton>
                    </CCol>
                </CRow>  
            }else{
                return <></>
            }
        }else{
            return <></>
        }
    }

    function previousPage(){
        let p=1;
        if(page>3){
            p = page-3;
        }else if(page>1 && page<=3){
            p = page-1;
        }
        setPage(p);
        getMarketplace('spaceship',p);
    }

    function nextPage(){
        const p = page+3;
        setPage(p);
        getMarketplace('spaceship',p);
    }

    function gotoPage(p){
        console.log('p ',p)
        setPage(p);
        getMarketplace('spaceship',p);
    }


    return ( 
        <CContainer>
            <CAlert color={infoColor} dismissible visible={visible} onClose={() => setVisible(false)}>{info}</CAlert>
            <CRow>
                {
                    marketplace.map((market,i) => 
                        <CCol sm='auto' key={market.onSale.objectId}>
                            <CCard className='mb-4' style={{width: '18rem'}}>
                                <CCardHeader><b>{market.spaceship.get('name')} {market.onSale.spaceship_id}</b></CCardHeader>
                                <CCardImage orientation='top' src={market.spaceship.get('image')}/>                                
                                <CCardBody>                                  
                                    <CRow >
                                        <CCol>
                                            Life :
                                        </CCol>
                                        <CCol>
                                            <CProgress >
                                                <CProgressBar value={market.spaceship.get('health')/5*100} >{market.spaceship.get('health')}</CProgressBar>
                                            </CProgress>                                            
                                        </CCol>                                        
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Level :
                                        </CCol>
                                        <CCol>
                                        <CProgress >
                                                <CProgressBar value={market.spaceship.get('level')/20*100} >{market.spaceship.get('level')}</CProgressBar>
                                            </CProgress>
                                        </CCol>
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Durability :
                                        </CCol>
                                        <CCol>
                                        <CProgress >
                                                <CProgressBar value={market.spaceship.get('durability')/market.spaceship.get('durability_max')*100} >{market.spaceship.get('durability')}</CProgressBar>
                                            </CProgress>
                                        </CCol>
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Power :
                                        </CCol>
                                        <CCol>
                                        <CProgress >
                                                <CProgressBar value={market.spaceship.get('power')/5*100} >{market.spaceship.get('power')}</CProgressBar>
                                            </CProgress>
                                        </CCol>
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Weapon 1 :
                                        </CCol>
                                        <CCol>
                                        {market.spaceship.get('weapon1')}
                                        </CCol>
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Weapon 2 :
                                        </CCol>
                                        <CCol>
                                        {market.spaceship.get('weapon2')}
                                        </CCol>
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Weapon 3 :
                                        </CCol>
                                        <CCol>
                                        {market.spaceship.get('weapon3')}
                                        </CCol>
                                    </CRow>
                                    <CRow className='mb-2'>
                                        <CCol>
                                            Special :
                                        </CCol>
                                        <CCol>
                                        {market.spaceship.get('special')}
                                        </CCol>
                                    </CRow>  
                                    <RenderBuyBtn spaceship_id={market.onSale.spaceship_id} price={market.onSale.price/10**18} seller={market.spaceship.get('ethAddress')}></RenderBuyBtn> 
                                                                  
                                </CCardBody>
                            </CCard>
                        </CCol>  
                    )
                }           
            </CRow>
            <CPagination >
                <CPaginationItem onClick={()=>previousPage()}>Previous</CPaginationItem>
                <CPaginationItem onClick={()=>gotoPage(page)}>{page}</CPaginationItem>
                <CPaginationItem onClick={()=>gotoPage(page+1)}>{page+1}</CPaginationItem>
                <CPaginationItem onClick={()=>gotoPage(page+2)}>{page+2}</CPaginationItem>
                <CPaginationItem onClick={()=>nextPage()}>Next</CPaginationItem>
            </CPagination>
        </CContainer>
       )
}

export default Spaceship