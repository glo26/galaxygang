import {
    CButton,
    CCard,
    CCardTitle,
    CCardText,
    CCardImage,
    CContainer,
    CAlert,   
    CFooter, 
    CModal,
    CModalBody,
    CModalHeader,
    CModalTitle,
    CRow,
    CCol,
    CImage,
    CCardBody,
  } from '@coreui/react' 
  import React,{useEffect, useState} from 'react'
import { useMoralis } from 'react-moralis'
import Web3 from 'web3'
import { Link } from 'react-router-dom'

  const Home = () => {
    const { isAuthenticated, user, Moralis} = useMoralis();
    let ethAddress="";

    useEffect(async()=>{
        if(isAuthenticated){
            ethAddress = user.get('ethAddress');
            
        }
    },[])

    return ( 
        <CContainer>
            <CRow className='mb-4'>
                <CCol>
                    <CCard className='p-4'>
                    <CCardTitle>Play Spaceshooter</CCardTitle>
                    <CCardImage src=""/>
                    <CCardText className="mb-2 text-medium-emphasis">Play our game to see what’s it like to be floating in the galaxy in your own super cool spaceships fighting alien.</CCardText>
                        
                        <CCardBody>
                            <CRow className="justify-content-center" xs={{ cols: 'auto' }}>
                            <CCol className=''>
                                <a href='https://gg-game-trial.netlify.app/' target='_blank'><CButton size='lg'>Free Trial</CButton></a>
                            </CCol>
                            <CCol className=''>
                                <Link to="/play_game"><CButton size="lg">Play</CButton></Link>
                            </CCol>
                            </CRow>
                        </CCardBody>                        
                    </CCard>
                </CCol>  
                <CCol>
                    <CCard className='p-4'>
                    <CCardTitle>Build Your Gang</CCardTitle>
                    <CCardImage src=""/>
                    <CCardText className="mb-2 text-medium-emphasis">Select your spaceship NFT to get started now, fight the aliens of our time, and get some Galaxy Treasures on the way!</CCardText>
                        
                        <CCardBody>
                            <CRow className="justify-content-center" xs={{ cols: 'auto' }}>
                                <CCol>
                                <Link to="/special_offer"><CButton size='lg'>Mint</CButton></Link>
                                </CCol>
                                <CCol>
                                <Link to="/marketplace/spaceship"><CButton size='lg'>Marketplace</CButton></Link>
                                </CCol>
                            </CRow>
                        </CCardBody>                        
                    </CCard>
                </CCol>              
            </CRow>            
        </CContainer>
    )
  }

  export default Home