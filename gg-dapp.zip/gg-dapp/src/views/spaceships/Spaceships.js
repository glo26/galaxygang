import React,{useEffect, useState} from 'react'
import {
    CButton,
    CCard,
    CCardBody,
    CCardHeader,
    CCardImage,
    CCol,
    CContainer,
    CProgress,
    CProgressBar,
    CRow, 
    CAlert,   
    CFormInput,
    CModal,
    CModalBody,
    CModalHeader,
    CModalTitle,
    CModalFooter,
    CPagination,
CPaginationItem
  } from '@coreui/react'  
import { useMoralis, useMoralisWeb3Api } from 'react-moralis'
import Web3 from 'web3'
import { nftAbi,nftAddress } from 'src/nft'
import { chainName } from 'src/global'
import { setGlobalState, useGlobalState } from 'src/state'
import { tokenAbi,tokenAddress } from 'src/token'
import { mpAbi, mpAddress } from 'src/marketplace'
import bannerIntro from 'src/assets/images/HowToPlayBanner.png'

  const Spaceships = () => {
    const { isAuthenticated, user, Moralis } = useMoralis();
    let ethAddress="";
    let [spaceships, setSpaceships] = useState([]);
    let [levelingCosts, setLevelingCosts] = useState([]);
    let [repairCosts, setRepairCosts] = useState([]);
    let [mpPrices, setMpPrices] = useState([]);
    const [visible, setVisible] = useState(false);
    let [info,setInfo] = useState("");
    let [infoColor, setInfoColor] = useState("primary");
    const [visibleModalSell, setVisibleModalSell] = useState(false);
    const [visibleModalIntro, setVisibleModalIntro] = useState(false);
    let [spaceshipSellSelected,setSpaceshipSellSelected] = useState(0);
    let [sellPrice, setSellPrice] = useState(0);
    let [disabled,setDisabled] = useState(false);
    let [page, setPage] = useState(1);
    const Web3API = useMoralisWeb3Api();
    let [first] = useGlobalState("firstAccess");

    useEffect(async()=>{
        if(isAuthenticated){
            ethAddress = user.get('ethAddress');
            await getSpaceships(page); 
            console.log("first ",first)   ;
            if(first ==1){
                setVisibleModalIntro(true);
                setGlobalState("firstAccess",0);
                first = 0;
            }        
        }
    },[])

    const getBalance = async() =>{        
        ethAddress = user.get('ethAddress');
        let web3 = new Web3(Moralis.provider);
        let contract = new web3.eth.Contract(tokenAbi, tokenAddress);     
        let result = await contract.methods.balanceOf(ethAddress).call({from:ethAddress});   
        setGlobalState("gxg",Math.floor(result/10**18));
    
        const params = {user_id:user.id};
        const userDetail = await Moralis.Cloud.run("syncUserDetail",params);        
        setGlobalState("sc",Math.floor(userDetail.get("space_credit")));
      } 


    async function syncSpaceship(){
        if(user){
            setDisabled(true);
            setInfo("Sync in progress..");
            setInfoColor("warning");
            setVisible(true);
            window.scrollTo(0, 0);
            ethAddress = user.get('ethAddress');     
            const options = { chain: chainName, address: ethAddress, token_address: nftAddress };
            const results = await Web3API.account.getNFTsForContract(options);            
            const nfts = results.result;  
            console.log("my nft ",nfts);
            //for(let i=0;i<nfts.length;i++){
            //   console.log("nft id: "+nfts[i].token_id);
                //const spaceshipDetail = await getSpaceshipNftDetail(nfts[i].token_id);
                //await cloudSyncSpaceship(nfts[i].token_id,spaceshipDetail);
                const params = {user:user.id,ethAddress:ethAddress, spaceships:nfts}
                await Moralis.Cloud.run("syncSpaceships",params);
            //}
            
            setDisabled(false);
            setInfo("Sync success!");
            setInfoColor("success");
            setVisible(true);
            window.scrollTo(0, 0);
            await getSpaceships(page);
        }else{
            setInfo("Connect your wallet!");
            setInfoColor("danger");
            setVisible(true);
            window.scrollTo(0, 0);
        }
    }
    

    async function getSpaceships(p) {//get list of all owned NFTs and sync to the database  
        if(user){
            const ships = [];
            const levCost = [];
            const repCost = [];
            const sales = [];
            const params = {user_id:user.id,page:p};      

            const spaceships= await Moralis.Cloud.run("spaceships",params);
            console.log('spaceships ',spaceships)
            for(let i=0;i<spaceships.length;i++){
                    const params = {rarity:spaceships[i].rarity};
                    const levelUpCost = await Moralis.Cloud.run("getLevelUpCost",params);
                    const paramsRep = {rarity:spaceships[i].rarity,durability:spaceships[i].durability};
                    const repairCost = await Moralis.Cloud.run("repairCost",paramsRep);

                    repCost.push(Math.round(repairCost));
                    levCost.push(levelUpCost);
                    ships.push(spaceships[i]);

                    const mpQuery = new Moralis.Query("Marketplace");
                    mpQuery.equalTo("spaceship_id",parseInt(spaceships[i].token_id));
                    mpQuery.equalTo("status","open");
                    const mp = await mpQuery.first();     
                    if(mp){
                        sales.push(parseInt(mp.get("price"))/10**18);
                    }else{
                        sales.push(0);
                    }
                }        
            setRepairCosts(repCost);
            setLevelingCosts(levCost);
            setSpaceships(ships);   
            setMpPrices(sales);
        }else{
            setInfo("Connect your wallet!");
            setInfoColor("danger");
            setVisible(true);
            window.scrollTo(0, 0);
        }
    }

    /*const getSpaceshipNftDetail = async(id) => {
        const web3 = new Web3(Moralis.provider);
        const contract = new web3.eth.Contract(nftAbi, nftAddress);
        const spaceship = await contract.methods.spaceships(id-1).call({from:ethAddress});
        return spaceship;
    }

    const cloudSyncSpaceship = async(id,nftDetail) => {
        ethAddress = user.get('ethAddress');
        const params = {token_id: id, nftDetail: nftDetail, user:user.id,ethAddress:ethAddress};
        return await Moralis.Cloud.run("syncSpaceship",params);
    }*/

    async function levelup(id){
        setDisabled(true);
        const params = {user_id:user.id,spaceship_id:id};
        await Moralis.Cloud.run("levelUpSpaceship",params);
        setInfo("Level Up Success!");
        setInfoColor("success");
        setVisible(true);
        window.scrollTo(0, 0);
        setDisabled(false);
        await getBalance();
        await getSpaceships(page);
        
    }

    async function sellToSc(spaceshipid,tokenid){
        setDisabled(true);
        ethAddress = user.get('ethAddress');      
      
        const web3 = new Web3(Moralis.provider);
        let contract = new web3.eth.Contract(nftAbi, nftAddress);
        await contract.methods.burn(tokenid).send({from:ethAddress})
        .on('receipt',async function(receipt){
            const params = {user_id:user.id,spaceship_id:spaceshipid};
            await Moralis.Cloud.run("sellSpaceshipToSc",params);
            setDisabled(false);
            setInfo("Salvage Success!");
            setInfoColor("success");
            setVisible(true);
            window.scrollTo(0, 0);
            await getBalance();
            await getSpaceships(page);
        })
        .on('error', function(error,receipt){
          console.log(error);
        });        
    }

    async function repair(id){
        setDisabled(true);
        const params = {spaceship_id:id, user_id:user.id};
        await Moralis.Cloud.run("repair",params);
        setDisabled(false);
        setInfo("Spaceship Repaired!");
        setInfoColor("success");
        setVisible(true);
        window.scrollTo(0, 0);
        await getBalance();
        await getSpaceships(page);
    }

    async function cancelSelling(spaceship_id){
        console.log('cancel ',spaceship_id)
        setDisabled(true);
        ethAddress = user.get('ethAddress');
        const web3 = new Web3(Moralis.provider);
        let mpContract = new web3.eth.Contract(mpAbi, mpAddress);
        await mpContract.methods.cancelSell(spaceship_id).send({from:ethAddress})
        .on('receipt',async function(receipt){
            const params = {ship_id:spaceship_id, user_id:user.id}
            await Moralis.Cloud.run("cancelSell",params);
            setDisabled(false);
            setInfo("Spaceship Selling Canceled!");
            setInfoColor("success");
            setVisible(true);
            window.scrollTo(0, 0);
            await getBalance();
            await getSpaceships(page);
        })
        .on('error', function(error,receipt){
          console.log(error);
        });
    }

    async function sell(){
        setDisabled(true);
        setVisibleModalSell(false);
        setInfo("Please wait...");
        setInfoColor("warning");
        setVisible(true);
        window.scrollTo(0, 0);
        ethAddress = user.get('ethAddress');
        const web3 = new Web3(Moralis.provider);    
        console.log('ship id ',spaceshipSellSelected)
        let nftContract = new web3.eth.Contract(nftAbi, nftAddress);
        await nftContract.methods.approve(mpAddress,spaceshipSellSelected).send({from:ethAddress})
        .on('receipt',async function(receipt){
        await sellEntry(user.id,spaceshipSellSelected,sellPrice);           
        })
        .on('error', function(error,receipt){
            console.log(error);
            window.location.reload();
        });
    }

    async function sellEntry(userid,id,price){
        const web3 = new Web3(Moralis.provider);
        const BN = web3.utils.BN;
        let priceBN = new BN((price*10**18).toString());
        let mpContract = new web3.eth.Contract(mpAbi, mpAddress);
        await mpContract.methods.selling(id,priceBN.toString()).send({from:ethAddress})
        .on('receipt',async function(receipt){
          console.log(receipt);
          //console.log(receipt.transactionHash);
          const params = {shipid:id,userid:userid,price:priceBN.toString()};
          await Moralis.Cloud.run("selling",params);          
          setDisabled(false);
          setInfo("Spaceship On Sale!");
          setInfoColor("success");
          setVisible(true);
          window.scrollTo(0, 0);
          await getBalance();
          await getSpaceships(page);
        })
        .on('error', function(error,receipt){
          console.log(error);
          window.location.reload();
        });
      }

    function showModalSell(ship_id){
        setVisibleModalSell(true);
        setSpaceshipSellSelected(ship_id);
        
    }

    function previousPage(){
        let p=1;
        if(page>3){
            p = page-3;
        }else if(page>1 && page<=3){
            p = page-1;
        }
        setPage(p);
        getSpaceships(p);
    }

    function nextPage(){
        const p = page+3;
        setPage(p);
        getSpaceships(p);
    }

    function gotoPage(p){
        console.log('p ',p)
        setPage(p);
        getSpaceships(p);
    }

    const RenderRarity = (props) => {
        if(props.rarity==1){
            return <>Common</>
        }else if(props.rarity==2){
            return <>Uncommon</>
        }else if(props.rarity==3){
            return <>Rare</>
        }else if(props.rarity==4){
            return <>Legendary</>
        }
    }

    const RenderQuickSellByRarity = (props) => {
        if(props.rarity==1){
            return <>200</>
        }else if(props.rarity==2){
            return <>400</>
        }else if(props.rarity==3){
            return <>600</>
        }else if(props.rarity==4){
            return <>800</>
        }
    }

    const RenderMarketplaceSell = (props) => {
        if(parseInt(props.mpPrice)>0){
            return <CRow className='mb-2'><CCol>on sale {props.mpPrice} SC </CCol><CCol><CButton onClick={()=>cancelSelling(props.token_id)} disabled={disabled}>Cancel Selling</CButton></CCol></CRow>;
        }else{
            //return <CRow className='mb-2'><CCol></CCol><CCol><CButton onClick={()=>sell(props.token_id,5)}>Sell</CButton></CCol></CRow>;//TODO:input selling price manually
            return <CRow className='mb-2'><CCol></CCol><CCol><CButton onClick={()=>showModalSell(props.token_id)} disabled={disabled}>Sell</CButton></CCol></CRow>;
        }
    }

    return (        
        <CContainer>
            <CAlert color={infoColor} dismissible visible={visible} onClose={() => setVisible(false)}>{info}</CAlert>
            <CCard className='mb-4'>
                <CCardBody>
                    <CButton onClick={()=>syncSpaceship()} disabled={disabled}>Sync Spaceship</CButton>
                </CCardBody>
            </CCard>
            <CRow>
                {
                    spaceships.map((spaceship,i) => 
                        <CCol sm='auto' key={i}>
                            <CCard className='mb-4' style={{width: '18rem'}}>
                                <CCardHeader><b>{spaceship.name} {spaceship.token_id}</b></CCardHeader>
                                <CCardImage orientation='top' src={spaceship.image}/>                                
                                <CCardBody>                                  
                                    <CRow >
                                        <CCol>
                                            Life :
                                        </CCol>
                                        <CCol>
                                            <CProgress >
                                                <CProgressBar value={spaceship.health/5*100} >{spaceship.health}</CProgressBar>
                                            </CProgress>                                            
                                        </CCol>                                        
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Level :
                                        </CCol>
                                        <CCol>
                                        <CProgress >
                                                <CProgressBar value={spaceship.level/20*100} >{spaceship.level}</CProgressBar>
                                            </CProgress>
                                        </CCol>
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Durability :
                                        </CCol>
                                        <CCol>
                                        <CProgress >
                                                <CProgressBar value={spaceship.durability/spaceship.durability_max*100} >{spaceship.durability}</CProgressBar>
                                            </CProgress>
                                        </CCol>
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Power :
                                        </CCol>
                                        <CCol>
                                        <CProgress >
                                                <CProgressBar value={spaceship.power/5*100} >{spaceship.power}</CProgressBar>
                                            </CProgress>
                                        </CCol>
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Weapon 1 :
                                        </CCol>
                                        <CCol>
                                        {spaceship.weapon1}
                                        </CCol>
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Weapon 2 :
                                        </CCol>
                                        <CCol>
                                        {spaceship.weapon2}
                                        </CCol>
                                    </CRow>
                                    <CRow>
                                        <CCol>
                                            Weapon 3 :
                                        </CCol>
                                        <CCol>
                                        {spaceship.weapon3}
                                        </CCol>
                                    </CRow>
                                    <CRow className='mb-2'>
                                        <CCol>
                                            Special :
                                        </CCol>
                                        <CCol>
                                        {spaceship.special}
                                        </CCol>
                                    </CRow>                                    
                                    <CRow className='mb-2'>
                                        <CCol>
                                            Level Up :
                                        </CCol>
                                        <CCol>
                                            <CButton onClick={() => levelup(spaceship.objectId)} disabled={disabled}>Pay {levelingCosts[i]} SC</CButton>
                                        </CCol>
                                    </CRow>
                                    <CRow className='mb-2'>
                                        <CCol>
                                            Salvage :
                                        </CCol>
                                        <CCol>
                                            <CButton onClick={()=>sellToSc(spaceship.objectId,spaceship.token_id)} disabled={disabled}>Get <RenderQuickSellByRarity rarity={spaceship.rarity}/> SC</CButton>
                                        </CCol>
                                    </CRow>
                                    <CRow className='mb-2'>
                                        <CCol>
                                            Repair :
                                        </CCol>
                                        <CCol>
                                            <CButton onClick={()=>repair(spaceship.objectId)} disabled={disabled}>Pay {repairCosts[i]} SC</CButton>
                                        </CCol>
                                    </CRow>
                                    <RenderMarketplaceSell mpPrice={mpPrices[i]} token_id={spaceship.token_id}/>
                                </CCardBody>
                            </CCard>
                        </CCol>  
                    )
                }           
            </CRow>
            <CPagination >
                <CPaginationItem onClick={()=>previousPage()}>Previous</CPaginationItem>
                <CPaginationItem onClick={()=>gotoPage(page)}>{page}</CPaginationItem>
                <CPaginationItem onClick={()=>gotoPage(page+1)}>{page+1}</CPaginationItem>
                <CPaginationItem onClick={()=>gotoPage(page+2)}>{page+2}</CPaginationItem>
                <CPaginationItem onClick={()=>nextPage()}>Next</CPaginationItem>
            </CPagination>
            <CModal visible={visibleModalSell} onClose={() => setVisibleModalSell(false)}>
                <CModalHeader onClose={() => setVisibleModalSell(false)}>        
                <CModalTitle>Input your price</CModalTitle>        
                </CModalHeader>        
                <CModalBody>
                    <CFormInput type="number" onInput={(e)=>{setSellPrice(e.target.value)}} onKeyPress={(event) => {
                        if (!/[0-9]/.test(event.key)) {
                        event.preventDefault();
                        }
                    }}/></CModalBody>        
                <CModalFooter>        
                    <CButton color="primary" onClick={()=>sell()} disabled={disabled}>Submit</CButton>        
                </CModalFooter>        
            </CModal>
            <CModal visible={visibleModalIntro} onClose={() => setVisibleModalIntro(false)}>
                <CModalHeader onClose={() => setVisibleModalIntro(false)}>          
                </CModalHeader>        
                <CModalBody>
                    <CCard>
                        <CCardImage src={bannerIntro}/>
                    </CCard>
                </CModalBody>        
                <CModalFooter>        
                    <CButton color="primary" href='https://satrio-galih.gitbook.io/galaxy-gang/getting-started' target="_blank" >Read More...</CButton>        
                </CModalFooter>        
            </CModal>
        </CContainer>        
    )
  }

  export default Spaceships