import React,{useEffect, useState} from 'react'
import {
    CButton,
    CCard,
    CCardImage,
    CContainer,
    CAlert,   
    CFooter,
    CCardBody,
    CRow,
    CCol,
    CFormInput
  } from '@coreui/react' 
import { useMoralis } from 'react-moralis'
import Web3 from 'web3'
import { nftAbi,nftAddress } from 'src/nft'
import { chainName } from 'src/global'
import { setGlobalState } from 'src/state'
import bannerImg from 'src/assets/images/1st-gen-spaceship.png'
import {tokenAbi, tokenAddress} from "src/token"

const Profile = () => {
    const { isAuthenticated, user, Moralis } = useMoralis();
    let ethAddress="";
    const [visible, setVisible] = useState(false);
    let [info,setInfo] = useState("");
    let [infoColor, setInfoColor] = useState("primary");
    let [username,setUsername] = useState("");
    let [password,setPassword] = useState("");

    useEffect(async()=>{
        if(isAuthenticated){
            ethAddress = user.get('ethAddress');
            await showUsername();
        }
    },[])

    async function showUsername(){
        setUsername(user.get('username'));
    }

    async function changePassword(){
        if(user){
        user.set("password",password);
        await user.save();
        setInfo("Password updated!");
        setInfoColor("success");
        setVisible(true);
        window.scrollTo(0, 0);
        }else{
            setInfo("Connect your wallet!");
            setInfoColor("danger");
            setVisible(true);
            window.scrollTo(0, 0);
        }
    }

    return ( 
        <CContainer>
            <CAlert color={infoColor} dismissible visible={visible} onClose={() => setVisible(false)}>{info}</CAlert>
            <CCard className='p-4' >
                <CCardBody>
                    <CRow className='mb-4'>
                        <CCol sm={2}>
                            Username :
                        </CCol>
                        <CCol>
                            {username} <CButton onClick={(e)=>{e.preventDefault();
                            navigator.clipboard.writeText(username);}} color="secondary" className='p-2'>Copy</CButton>
                        </CCol>
                        <CCol></CCol>
                    </CRow>
                    <CRow>
                        <CCol sm={2}>
                            Password :
                        </CCol>
                        <CCol>
                            <CFormInput type="password" onInput={(e)=>{setPassword(e.target.value)}}/>
                        </CCol>
                        <CCol>
                            <CButton onClick={()=>changePassword()}>Save Change</CButton>
                        </CCol>
                    </CRow>
                </CCardBody>
            </CCard>
        </CContainer>
       )
}

export default Profile