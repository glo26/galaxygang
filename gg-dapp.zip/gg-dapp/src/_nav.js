import React from 'react'
import CIcon from '@coreui/icons-react'
import {
  cilCopy,  
  cilUser,
  cilGamepad,
  cilGift,
  cilBurn,
  cilCart,
  cilAirplaneMode,
} from '@coreui/icons'
import { CNavItem,CNavGroup } from '@coreui/react'

const _nav = [
  {
    component: CNavItem,
    name: 'Spaceships',
    to: '/spaceships',
    icon: <CIcon icon={cilAirplaneMode} customClassName="nav-icon" />
  },
  {
    component: CNavGroup,
    name: 'Marketplace',
    to: '/marketplace',
    icon: <CIcon icon={cilCart} customClassName="nav-icon" />,
    items: [
      {
        component: CNavItem,
        name: 'Spaceship',
        to: '/marketplace/spaceship',
      },
      {
        component: CNavItem,
        name: 'Space Credit',
        to: '/marketplace/sc',
      },
    ],
  },
  {
    component: CNavItem,
    name: 'Special Offer',
    to: '/special_offer',
    icon: <CIcon icon={cilBurn} customClassName="nav-icon" />,
  },
  {
    component: CNavItem,
    name: 'Fusion',
    to: '/fusion',
    icon: <CIcon icon={cilCopy} customClassName="nav-icon" />,    
  },
  {
    component: CNavItem,
    name: 'Rewards',
    to: '/rewards',
    icon: <CIcon icon={cilGift} customClassName="nav-icon" />,    
  },
  {
    component: CNavItem,
    name: 'Profile',
    to: '/profile',
    icon: <CIcon icon={cilUser} customClassName="nav-icon" />,    
  },
  {
    component: CNavItem,
    name: 'Play Game',
    to: '/play_game',
    icon: <CIcon icon={cilGamepad} customClassName="nav-icon" />,
  },  
]

export default _nav
